﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Hilva;
using Microsoft.Xna.Framework;

namespace PostProcessSample
{
    class Camera : ICamera
    {
        public Vector3 Position = Vector3.Backward * 5;
        public Vector3 Target = Vector3.Zero;
        public Vector3 Up = -Vector3.Up;

        #region IViewPoint Members

        public Matrix InvertView
        {
            get
            {
                return Matrix.Invert(View);
            }
        }

        public Matrix InvertViewProjection
        {
            get
            {
                return Matrix.Invert(ViewProjection);
            }
        }

        Vector3 ICamera.Position
        {
            get { return Position; }
        }

        public Matrix Projection
        {
            get
            {
                return Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, 1.33f, 1, 1000);
            }
        }

        public Matrix View
        {
            get
            {
                return Matrix.CreateLookAt(Position, Target, Up);
            }
        }

        public Matrix ViewProjection
        {
            get
            {
                return View * Projection;
            }
        }

        #endregion
    }
}
