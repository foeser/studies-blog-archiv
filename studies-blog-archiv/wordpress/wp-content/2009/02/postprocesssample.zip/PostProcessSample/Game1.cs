//Thanks to Florian Oeser (www.florian-oeser.de)

using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using PostProcessSample.PostProcess;
using Hilva.Models;
using Hilva.Materials.Forward;

namespace PostProcessSample
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont fnt = null;

        RenderTarget2D target;
       
        Camera camera = new Camera();

        Hilva.Models.Model model = null;
        TextureMapping_DirectionalLighting textureMapping = null;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            camera.Position = Vector3.Backward * 200;

            target = new RenderTarget2D(this.GraphicsDevice, this.GraphicsDevice.PresentationParameters.BackBufferWidth, this.GraphicsDevice.PresentationParameters.BackBufferHeight, 1,
                                        this.GraphicsDevice.PresentationParameters.BackBufferFormat);           
            
            this.Components.Add(new PostProcessEffectManager(this, target));
            PostProcessEffectManager.AddEffect(new PixelateEffect(this.GraphicsDevice), PostProcessEffectManager.PostProcessEffectNumber._pixelate);
            PostProcessEffectManager.AddEffect(new SmartBlurEffect(this.GraphicsDevice), PostProcessEffectManager.PostProcessEffectNumber._smartBlur);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            model = Content.Load<Hilva.Models.Model>("Tiny");
            fnt = Content.Load<SpriteFont>("Arial");

            textureMapping = new TextureMapping_DirectionalLighting(GraphicsDevice, false, false);
            textureMapping.Camera = camera;
                         
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();           

            if (Keyboard.GetState().IsKeyDown(Keys.F1))
            {
                PostProcessEffectManager.SetActiveEffect(PostProcessEffectManager.PostProcessEffectNumber._ripple);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.F2))
            {
                PostProcessEffectManager.SetActiveEffect(PostProcessEffectManager.PostProcessEffectNumber._pixelate);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.F3))
            {
                PostProcessEffectManager.SetActiveEffect(PostProcessEffectManager.PostProcessEffectNumber._smartBlur);
            }
            
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            PostProcessEffectManager.BeginTarget();

            textureMapping.World = Matrix.CreateRotationX(-MathHelper.PiOver2) * Matrix.CreateRotationY((float)gameTime.TotalGameTime.TotalSeconds) * Matrix.CreateScale(0.2f);
            textureMapping.Begin();
            foreach (Mesh modelMesh in model.Meshes)
            {

                foreach (MeshPart part in modelMesh.MeshParts)
                {
                    try
                    {
                        textureMapping.ColorTexture = part.Textures[0];
                        textureMapping.LightDirection = Vector3.Forward;
                    }
                    catch { }

                    textureMapping.DrawModelMeshPart(part);
                }
            }
            textureMapping.End();
            
            PostProcessEffectManager.EndTarget();
            PostProcessEffectManager.Draw();

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.SaveState);
            spriteBatch.DrawString(
                fnt,
                "Press F1-F3 to switch through effects.\n"
                + "Applied effect: " + PostProcessEffectManager.ActiveEffect.ToString(),
                new Vector2(10, 10),
                Color.White
                );
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
