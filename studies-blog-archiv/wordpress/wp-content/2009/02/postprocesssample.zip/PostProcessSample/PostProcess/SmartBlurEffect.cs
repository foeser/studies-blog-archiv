using System;
using System.Collections.Generic;
using System.Text;
using Hilva.PostProcess.Blur;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PostProcessSample.PostProcess
{
    public class SmartBlurEffect : PostProcessEffect
    {
        private SmartBlur _smartBlur;

        public float Amount
        {
            set { _smartBlur.Amount = value; }
            get { return _smartBlur.Amount; }
        }

        public SmartBlurEffect(GraphicsDevice device)
            : base(device)
        {
            _smartBlur = new SmartBlur(device);           
        }

        public override void Draw()
        {
            _smartBlur.PostProcess(PostProcessEffectManager.Target.GetTexture(), null);            
        }

        public override string ToString()
        {
            return "SmartBlur";
        }
    }
}