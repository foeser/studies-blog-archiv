#region Filedescription
/********************************************************************
	
 * project:         zPhere
 * namespace:       zPhere.Managers
 * class:           PostProcessEffectManager
 * creation date:   2008/10/13
 * author:          Forian Oeser  
	

 * last changes:	
 * 
 
 * We're using GraphiXNA Shading Library for PostProcessing, Particles and later Material...
 * http://www.codeplex.com/GraphiXNA
 
*********************************************************************/
#endregion
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using System.Collections;
using Hilva.PostProcess;
using Microsoft.Xna.Framework.Graphics;

namespace PostProcessSample.PostProcess
{
    public class PostProcessEffectManager : GameComponent
    {
        #region Properties
        
        /// <summary>
        /// A hashtable that holds all effects getting added
        /// </summary>
        private static Hashtable _effects = new Hashtable();       

        public enum PostProcessEffectNumber
        {            
            _ripple = 1,            
            _pixelate = 2,
            _smartBlur = 3,
        }      

        private static PostProcessEffect _activeEffect;
        /// <summary>
        /// The effect which would be drawn.
        /// </summary>
        public static PostProcessEffect ActiveEffect
        {
            get { return _activeEffect; }
        }

        private static RenderTarget2D _target;

        public static RenderTarget2D Target
        {
            get { return _target; }
            set { _target = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create the PostProcessEffectManager.
        /// </summary>
        /// <param name="game"></param>
        public PostProcessEffectManager(Game game, RenderTarget2D target)
            : base(game)
        {
            Target = target;
            
            AddEffect(new RippleEffect(game.GraphicsDevice), PostProcessEffectNumber._ripple);
            SetActiveEffect(PostProcessEffectNumber._ripple);           
            Enabled = true;
        }

        /// <summary>
        /// Create the effects.
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();            
        }        

        /// <summary>
        /// Update the active effect.
        /// </summary>
        /// <param name="gameTime"></param>
        public static void Draw()
        {          
            _activeEffect.Draw();
        }

        /// <summary>
        /// Calls the BeginTarget() of the active effect
        /// </summary>
        public static void BeginTarget()
        {          
           _activeEffect.BeginTarget();
        }

        /// <summary>
        /// Calls the EndTarget() of the active effect
        /// </summary>
        public static void EndTarget()
        {          
           _activeEffect.EndTarget();
        }

        /// <summary>
        /// Adds a new effect to the PostProcessingEffectManager
        /// </summary>
        /// <param name="newEffect"></param>
        /// <param name="effectNumber"></param>
        public static void AddEffect(PostProcessEffect newEffect, PostProcessEffectNumber effectNumber)
        {
            if (!_effects.Contains(effectNumber))
            {
                _effects.Add(effectNumber, newEffect);
            }
        }       

        /// <summary>
        /// Changes the active effect by label
        /// </summary>
        /// <param name="effectNumber"></param>
        public static void SetActiveEffect(PostProcessEffectNumber effectNumber)
        {
            if (_effects.ContainsKey(effectNumber))
            {
                _activeEffect = _effects[effectNumber] as PostProcessEffect;
            }
        }

        #endregion

    }
}
