using System;
using System.Collections.Generic;
using System.Text;
using Hilva.PostProcess.Color;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PostProcessSample.PostProcess
{
    public class PixelateEffect : PostProcessEffect
    {

        private Pixelate _pixelate;

        public float NumberofPixels
        {
            set { _pixelate.NumberOfPixels = value; }            
        }

        public Vector3 EdgeColor
        {
            set { _pixelate.EdgeColor = value; }
        }

        public float EdgeThickness
        {
            set { _pixelate.EdgeThickness = value; }            
        }

        public PixelateEffect(GraphicsDevice device)
            : base(device)
        {
            _pixelate = new Pixelate(device);            
        }

        public override void Draw()
        {
            _pixelate.PostProcess(PostProcessEffectManager.Target.GetTexture(), null);
        }

        public override string ToString()
        {
            return "Pixelate";
        }
    }
}