﻿using System;
using System.Collections.Generic;
using System.Text;
using Hilva.PostProcess.Displacement;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PostProcessSample.PostProcess
{
    public class RippleEffect : PostProcessEffect
    {

        private Ripple _ripple;                

        public RippleEffect(GraphicsDevice device)
            : base(device)
        {
            _ripple = new Ripple(device);           
        }

        public override void Draw()
        {
            _ripple.PostProcess(PostProcessEffectManager.Target.GetTexture(), null);
        }

        public override string ToString()
        {
            return "Ripple";
        }
    }
}
