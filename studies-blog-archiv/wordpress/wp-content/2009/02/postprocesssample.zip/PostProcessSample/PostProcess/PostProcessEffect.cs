using System;
using System.Collections.Generic;
using System.Text;
using Hilva.PostProcess;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PostProcessSample.PostProcess
{
    public abstract class PostProcessEffect
    {       
        private GraphicsDevice device;

        public PostProcessEffect(GraphicsDevice device)
        {
            this.device = device;           
        }

        public void BeginTarget()
        {
            device.SetRenderTarget(0, PostProcessEffectManager.Target);
        }

        public void EndTarget()
        {
            device.SetRenderTarget(0, null);
            
        }

        public abstract void Draw();
    }
}
