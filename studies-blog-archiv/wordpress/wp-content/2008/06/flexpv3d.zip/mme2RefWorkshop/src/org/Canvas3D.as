/* 
	workshop mme2 am 06.05.2008
	class: Canvas3D.as
	based on: http://the.fontvir.us/b10g/?id=106 by xero
	angepasst von: radioSiTY Team
	
	project: radiosity

	steuer klasse zur aufteilung der UI und verarbeitung der 3d objekte
*/

package org{
	import mx.core.*;
	import flash.display.*;	
	import org.papervision3d.view.*;	

	public class Canvas3D extends UIComponent
	{	
		// sprite und view für die 3d sicht
		private var paperSprite	:Sprite;
		private var theview		:BasicView;
		
		// parameter zur initialisierung der UIComponente
		private var theWidth	:Number  = 0;
		private var theHeight	:Number  = 0;
		private var autoScale	:Boolean = false;
		private var interactive	:Boolean = false;
		private var autoClip	:Boolean = true;
		private var autoCull	:Boolean = true;
				
		public function Canvas3D()
		{
			// aufruf der super klasse zur erstellung eines neuen UI
			super();
		}
				
		override protected function createChildren():void
		{
			// erstellung eines kinds in diesem UI
			super.createChildren();
			// sprote zur übergabe an die super klasse
			paperSprite = new Sprite();
			
			// erstellen einer kamerasicht auf das UI (angabe von höhe, breite, skalierung etc.)
			theview = new BasicView(theWidth, theHeight, autoScale, interactive);
			theview.viewport.autoClipping = autoClip;
			theview.viewport.autoCulling = autoCull;

			// einbindung der view in die sprite
			paperSprite.addChild(theview);		
			// einbindung der sprite auf unser UI	
			addChild(paperSprite);	
		}
				
		/*
			setter und getter für verschiedene parameter
		*/
		public function set viewWidth(w:Number):void
		{
			theWidth = w;	
		}
		
		public function get viewWidth():Number
		{
			return theWidth;	
		}

		public function set viewHeight(h:Number):void
		{
			theHeight = h;	
		}
		
		public function get viewHeight():Number
		{
			return theHeight;	
		}

		public function set autoScaleMode(bool:Boolean):void
		{
			autoScale = bool;	
		}
		
		public function get autoScaleMode():Boolean
		{
			return autoScale;	
		}

		public function set interactivity(bool:Boolean):void
		{
			interactive = bool;	
		}
		
		public function get interactivity():Boolean
		{
			return interactive;	
		}

		public function set autoClipMode(bool:Boolean):void
		{
			autoClip = bool;	
		}
		
		public function get autoClipMode():Boolean
		{
			return autoClip;	
		}

		public function set autoCullMode(bool:Boolean):void
		{
			autoCull = bool;	
		}
		
		public function get autoCullMode():Boolean
		{
			return autoCull;	
		}
		
		public function get canvas():Sprite
		{
			return paperSprite;
		}

		public function get view():BasicView
		{
			return theview;
		}
	}
}