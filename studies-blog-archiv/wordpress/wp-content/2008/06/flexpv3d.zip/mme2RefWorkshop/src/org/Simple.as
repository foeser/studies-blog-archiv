/* 
	workshop mme2 am 06.05.2008
	class: simple.as
	erstellt von: michael palmer - radioSiTY Team
	michaelpalmer.de
	
	project: radiosity

	einbinden von 3 einfachen objekten in den flex 3d raum
*/

package org{
	import flash.events.Event;
	
	import org.papervision3d.cameras.*;
	import org.papervision3d.materials.*;
	import org.papervision3d.materials.utils.MaterialsList;
	import org.papervision3d.objects.*;
	import org.papervision3d.objects.primitives.*;
	import org.papervision3d.view.*;

	public class Simple {
	    // übergabe parameter (viewport 4 cam, szene etc.)
	    private var view		:BasicView;
	    
	    // global vars für simple 3d objekte
	    private var mySphere	:Sphere;
	    private var mySphere2	:Sphere;
	    private var myCube		:Cube;

		public function Simple (view:BasicView) {
			// übergabe der view aus Canvas3D an meine simple klasse		 		
			this.view = view;
	    	createCube();
	    }
	    
	    private function createCube ():void {
			/*
	    	 erstellung einer einfachen Sphere
	    	 -> material (einseitig) wird um den körper gelegt
	    	 	-> WireframeMaterial (farbe, alpha, stärke)
	    	 -> radius, segmente breite, segmente höhe
	    	*/
			mySphere = new Sphere(new WireframeMaterial(0xFFFFFF, 0.3, 2), 200, 16, 16);
			// verschieben des objektes auf der x achse
	    	mySphere.moveLeft(500);
	    	// einbindung des 3d körpers auf die bühne, in diesem fall in die szene
	    	view.scene.addChild(mySphere);	
	    	
	    	/*
	    	 erstellung einer einfachen Sphere
	    	 -> material (einseitig) wird um den körper gelegt
	    	 	-> BitmapFileMaterial (pfad zum bild)
	    	 -> radius, segmente breite, segmente höhe
	    	*/
	    	mySphere2 = new Sphere(new BitmapFileMaterial("./img/1.jpg"), 200, 16, 16);
	    	// positionieren des objektes auf der x achse
	    	mySphere2.x = 500;
	    	// einbindung des 3d körpers auf die bühne, in diesem fall in die szene
			view.scene.addChild(mySphere2);
	    	
	    	/*
	    	 erstellung eines einfachen cubes
	    	 -> materiallist mit 4 seiten angaben
	    	 -> breite, tiefe, höhe 
	    	 -> segmente an den seiten
	    	*/
	    	myCube = new Cube(new MaterialsList({
	    						all: new WireframeMaterial( 0x00FF00, 0.5 )
	    										}), 300, 300, 300, 4, 4);
	   		// einbindung des 3d körpers auf die bühne, in diesem fall in die szene
			view.scene.addChild(myCube);	
	    }
	    
	    public function onEnterFrame(e:Event):void {
	    	/*
	    	 positionierung der einzelnen elemente im raum
	    	 yaw: virtuelle y achse
	    	 roll: virtuelle z achse
	    	 pitch: virtuelle x achse
	    	 y     z
	    	 |   /
	    	 |  /
	    	 | /
	    	 -------- x
	    	*/
	    	
			myCube.yaw(2);
			myCube.pitch(2);
			
			mySphere.yaw(2);
			
			mySphere2.roll(2);
			mySphere2.yaw(2);
			
			// rendern der szene (mti übergabe der parameter - scene, kamera, und der view)
			view.renderer.renderScene(view.scene, view.camera, view.viewport);
	    }
	}
}